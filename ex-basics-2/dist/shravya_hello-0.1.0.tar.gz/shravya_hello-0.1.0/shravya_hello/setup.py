entry_points={
    "console_scripts": [
        "shravya-hello = shravya_hello.cli:main",
    ],
},
