# mypkg/cli.py
def main():
    print("Hello from my tool!")
